<?php 
// Tidak bisa membuat nama class yang sama
// class conflict{

// }
// class conflict{

// }

// Solusi
namespace Data\One{
    class conflict{

    }
}

namespace Data\Two{
    class conflict{
        
    }
}
?>