<?php 
require_once "conflict.php";
// Membuat Objek dari kelas conflict
$conflic1 = new \Data\One\conflict();
$conflic2 = new \Data\Two\conflict();
?>